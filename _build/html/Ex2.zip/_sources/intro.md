<!-- #region -->
# The Purpose of this Workshop

The 2023 Strategy has made a priority of Digitalization in education in the University. This workshop is an introduction to the topic of digitalization, and provides an opportunity to capture your own thoughts about the fast-changing technological environment we all inhabit, while also providing first introduction to the tools and techniques of data analysis.

We have designed a set of activitites which both fulfil the need to identify the thoughts and ideas of teachers in faculties, whilst using this data collection activity as a way of providing a meaningful context for introducing you to digitalization tools. 

In the first set of activities, you are asked to engage with a set of questionnaires, making comparisons between different value positions with regard to the future of education, and different opinions about what matters. 

In the second set of activities, we will show you how digitalization tools can analyze this data, using this workbook as a live programming tool. (If you are interested in the workbook itself, we will show you how to make one yourself!)

In the final set of activities, we want you to think about how you might introduce a digital activity in your discipline, describing the tools, activities, objectives and challenges of doing this.

We hope you enjoy it!



## Why Digitalization?
Barely a day goes by without someone mentioning the rapid advances in the way the internet is shaping our lives.  From the miraculous achievements of Articial Intelligence to the political problems produced by social media, the 'digital' is becoming increasingly important. 

It is often said that the jobs of tomorrow don't exist yet. But there are indications as to the kinds of skills that are increasingly important in industry: 
1. Skills in making sense from complex data
2. SKills in presenting and visualising data
3. Skills in developing new kinds of application
4. Skill in communicating between highly technical levels and deeply human

In many cases and in many courses across the University, some of these skills are being taught. But it can be supported better, and it can be coordinated and developed more effectively.

For this reason, these workshops are designed to identify:
1. What aspects of digitalisation already exist in the departments?
2. What would digitalisation change about the humanities?
3. How do humanities professors define digitalisation?
4. What role do professors see for themselves within the digitisation initiative?


# Plan
Duration: 2 hours
Location: ideally in person (adapted for online)


# Introduction
Education, values and digitalization
This is a short exercise to explore what you think matters in education, what is changing with technology, and how you think education is likely (or should) change

There are four "values" positions, which we want you to compare. We will show you how the data from this exercise can then be used as an example in using computational tools. 


## Activities
What is digitalisation

### Digitalization as changing practice
Computational techniques for data analysis, data visualisation, simulation and machine learning are becoming increasingly ubiquitous across all sectors of employment. This is leading employers and governments to demand a new range of skills from graduates, while universities across the world are having to adapt their educational provision to prepare students for a fast-changing world where technical flexibility is increasingly important. How can and should universities respond to this challenge where the fundamental coordination between universities and society must increasingly balance discipline-specific conceptual knowledge with common computational practices? What does this mean for the way we organise education?

## objectives
participants reflect on their own understanding of what digitalisation is
model using text analysis to identify core ideas that constitute digitalisation (set up discussion of the uses and limitations of text analysis)
#### build a working model of digitalisation that is relevant and field specific

# Imagining the Future: Future positions
Using a set of resource articulating core values and positions with regard to the future of education, how do you think your discipline should respond to the challenges of digitalization?

How would your field change in the next 10 years

## objectives
Gather data about positions and values from participants for analysis using computational tools in the next section

# Introduction to Computational Tools
In this section we will show you how to use some of the computational tools for analysing the data which you submitted in the previous exercise.

We will introduce you to online programming environments, and to how the resources contained in this workbook can be used and executed in a live programming environment.


# Designing Digitalized Courses
In the light of the tools and techniques you have been shown, we ask you to work in groups to define a "digital/data learning activity in your subject area. 

We ask you to define the task, the tools used, what the learners are told, and what they will produce.

## objectives
design a way that current courses could be modified
evaluate changes of proposed objectives
optional: provide examples to stimulate discussion, groups can rank the relevance for their courses and discuss specific activities in groups


# Summary, Discussion and Next Steps
<!-- #endregion -->
